# Amoeba > 2024-06-08 2:40am
https://universe.roboflow.com/osteo-cluav/amoeba-k9oi0

Provided by a Roboflow user
License: CC BY 4.0

